import Cocoa

// Решить квадратное уравнение
let Y = "15-(2*x)-(x^2)=0"
let a = -1
let b = -2
let c = 15
let d = (Double(b*b) - Double(4 * (a*c)))
print (d)
let x1 = (Double(b)*(-1)+sqrt(Double(d)))/(Double(2*a))
print (x1)
let x2 = (Double(b)*(-1)-sqrt(Double (d)))/(Double(2*a))
print (x2)

// Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.
let catet1 = 6
let catet2 = 8
let S = (Double(catet1*catet2))/2
print (S)
let gipotenyza = sqrt(Double(catet1*catet1)+Double(catet2*catet2))
print (gipotenyza)
let P = (Double(catet1 + catet2) + gipotenyza)
print (P)

//Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.
let deneg = 50000
let procent = 1.25
let srok = 5
let vklad = (pow(Double(procent),5)*(Double(deneg)))
print (vklad)
